api.addButtonToToolbar({
    title: 'Weight Tracker',
    icon: 'tachometer',
    action: async () => api.activateNote(await api.startNote.getRelationValue('targetNote'))
});