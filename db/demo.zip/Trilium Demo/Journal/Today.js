api.addButtonToToolbar({
    title: 'Today',
    icon: 'calendar',
    shortcut: 'alt+t',
    action: async function() {
        const todayNote = await api.getTodayNote();

        await api.waitUntilSynced();
        
        api.activateNote(todayNote.noteId);
    }
});