const notes = await api.runOnBackend(async () => {
    return api.sql.getRows(`
        SELECT
            notes.noteId,
            notes.contentLength + COALESCE(SUM(note_revisions.contentLength), 0) AS size
        FROM notes
        LEFT JOIN note_revisions ON note_revisions.noteId = notes.noteId 
                                AND note_revisions.isErased = 0
        WHERE notes.isDeleted = 0
        GROUP BY notes.noteId
        ORDER BY size DESC
        LIMIT 100`);
});

const $statsTable = api.$container.find('.stats-table');

for (const note of notes) {     
    $statsTable.append(
        $("<tr>")
            .append(
                $("<td>").append(await api.createNoteLink(note.noteId, {showNotePath: true}))
            ) 
            .append(
                $("<td nowrap>").text(note.size + " bytes")
            )
    );
}