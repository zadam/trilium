api.addButtonToToolbar({
    title: 'Today',
    icon: 'calendar',
    shortcut: 'alt+t',
    action: async function() {
        const todayDateStr = api.formatDateISO(new Date());

        const todayNote = await api.runOnServer(async todayDateStr => {
            return await api.getDateNote(todayDateStr);
        }, [todayDateStr]);

        api.activateNote(todayNote.noteId);
    }
});