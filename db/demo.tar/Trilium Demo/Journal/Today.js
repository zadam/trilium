api.addButtonToToolbar({
    title: 'Today',
    icon: 'calendar',
    shortcut: 'alt+t',
    action: async function() {
        const todayDateStr = api.formatDateISO(new Date());

        const todayNote = await api.runOnServer(async todayDateStr => {
            return await api.getDateNote(todayDateStr);
        }, [todayDateStr]);

        const dateCreated = api.parseDate(todayNote.dateCreated);

        // newly created note isn't in the tree cache yet
        if (new Date().getTime() - dateCreated.getTime() < 60 * 1000) {
            await api.refreshTree();
        }

        api.activateNote(todayNote.noteId);
    }
});