api.addButtonToToolbar({
    title: 'Weight Tracker',
    icon: 'star',
    action: () => api.activateNote('8LOr7xUMuWD4')
});