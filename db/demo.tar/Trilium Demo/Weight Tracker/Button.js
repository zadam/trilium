api.addButtonToToolbar({
    title: 'Weight Tracker',
    icon: 'star',
    action: async () => api.activateNote(await api.startNote.getRelationValue('targetNote'))
});